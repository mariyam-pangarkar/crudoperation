<!DOCTYPE html>
<html>
<head>
	<title>crud operation</title>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
<div class="container">
	<?php echo $__env->yieldContent('content'); ?>
	
</div>
</body>
</html><?php /**PATH /home/abrar/Downloads/module/lara2/resources/views/products/layout.blade.php ENDPATH**/ ?>